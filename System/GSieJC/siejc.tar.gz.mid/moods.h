#ifndef _MOODS_H
#define _MOODS_H

void Show_Moods_Menu();

#endif
