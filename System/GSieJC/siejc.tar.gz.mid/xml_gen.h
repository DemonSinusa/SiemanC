#ifndef _XML_GEN_H_
#define _XML_GEN_H_

XMLNode * XML_CreateNode(char *name, char *value);

int XML_Set_Attr_Value(XMLNode *node, char *attr_name, char *attr_value);

char * XML_Get_Node_As_Text(XMLNode *node);

#endif
