#ifndef _TRANSPORTS_ICONS_H_
#define _TRANSPORTS_ICONS_H_

typedef struct
{
  void * next;
  char name[32];
}TransportIconsList;

void LoadTranspostIconsList();
void FreeTranspostIconsList();
void GetTransportIconsPath(char * path_to_pic, TRESOURCE * resEx);

#endif /* _TRANSPORTS_ICONS_H_ */
