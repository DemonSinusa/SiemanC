#include <cfg_items.h>
#include "lang.h"
//������������

__CFG_BEGIN(1)

__root const CFG_HDR cfgcolor1={CFG_COLOR,"CURSOR",0,0};
__root const char CURSOR_c[4]={0x78,0x78,0xFF,0x64};

__root const CFG_HDR cfgcolor2={CFG_COLOR,"CURSOR_OB",0,0};
__root const char CURSOR_BORDER_c[4]={0xC8,0xC8,0xC8,0x64};

__root const CFG_HDR cfgcolor3={CFG_COLOR,"SHRIFT",0,0};
__root const char CLIST_F_COLOR_0_c[4]={0x00,0x00,0x00,0x64};

__root const CFG_HDR cfgcolor4={CFG_COLOR,"CONTACT_LIST_SHRIFT_NEWMES",0,0};
__root const char CLIST_F_COLOR_1_c[4]={0x00,0x00,0xAA,0x64};

__root const CFG_HDR cfgcolor5={CFG_COLOR,"CONTACT_LIST_FON1",0,0};
__root const char CONTACT_BG_0_c[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfgcolor6={CFG_COLOR,"CONTACT_LIST_FON2",0,0};
__root const char CONTACT_BG_1_c[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfgcolor7={CFG_COLOR,"//Empty",0,0};
__root const char lineColor_c[4]={0x00,0x00,0x00,0x64};

__root const CFG_HDR cfgcolor8={CFG_COLOR,"//Empty",0,0};
__root const char borderColor_c[4]={0x00,0x00,0x00,0x64};

__root const CFG_HDR cfgcolor9={CFG_COLOR,"BG_NOT_CONNECTED",0,0};
__root const char MAINBG_NOT_CONNECTED_c[4]={0x32,0x32,0x32,0x64};

__root const CFG_HDR cfgcolor10={CFG_COLOR,"BG_CONNECTED",0,0};
__root const char MAINBG_CONNECTED_c[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfgcolor11={CFG_COLOR,"BG_ERROR",0,0};
__root const char MAINBG_ERROR_c[4]={0xFF,0x00,0x00,0x64};

__root const CFG_HDR cfgcolor12={CFG_COLOR,"FONT_CONNECTED",0,0};
__root const char MAINFONT_CONNECTED_c[4]={0x64,0x64,0x64,0x64};

__root const CFG_HDR cfgcolor13={CFG_COLOR,"FONT_ERROR",0,0};
__root const char MAINFONT_ERROR_c[4]={0xFF,0x00,0x00,0x64};

__root const CFG_HDR cfgcolor14={CFG_COLOR,"MESSAGEWIN_BGCOLOR",0,0};
__root const char MESSAGEWIN_BGCOLOR_c[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfgcolor15={CFG_COLOR,"MESSAGEWIN_TITLE_BGCOLOR",0,0};
__root const char MESSAGEWIN_TITLE_BGCOLOR_c[4]={0x00,0x00,0xFF,0x64};

__root const CFG_HDR cfgcolor16={CFG_COLOR,"MESSAGEWIN_TITLE_FONT",0,0};
__root const char MESSAGEWIN_TITLE_FONT_c[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfgcolor17={CFG_COLOR,"MESSAGEWIN_MY_BGCOLOR",0,0};
__root const char MESSAGEWIN_MY_BGCOLOR_c[4]={0xC8,0xD7,0xFF,0x64};

__root const CFG_HDR cfgcolor18={CFG_COLOR,"MESSAGEWIN_CH_BGCOLOR",0,0};
__root const char MESSAGEWIN_CH_BGCOLOR_c[4]={0xE9,0xE9,0xE9,0x64};

__root const CFG_HDR cfgcolor19={CFG_COLOR,"MESSAGEWIN_CURSOR_BGCOLOR",0,0};
__root const char MESSAGEWIN_CURSOR_BGCOLOR_c[4]={0xFF,0xFF,0x00,0x64};

__root const CFG_HDR cfgcolor20={CFG_COLOR,"MESSAGEWIN_GCHAT_BGCOLOR_1",0,0};
__root const char MESSAGEWIN_GCHAT_BGCOLOR_1_c[4]={0xFF,0xFF,0xFF,0x64};

__root const CFG_HDR cfgcolor21={CFG_COLOR,"MESSAGEWIN_GCHAT_BGCOLOR_2",0,0};
__root const char MESSAGEWIN_GCHAT_BGCOLOR_2_c[4]={0xE9,0xE9,0xE9,0x64};

__root const CFG_HDR cfgcolor22={CFG_COLOR,"MESSAGEWIN_SYS_BGCOLOR",0,0};
__root const char MESSAGEWIN_SYS_BGCOLOR_c[4]={0x73,0xAA,0xF0,0x64};

__root const CFG_HDR cfgcolor23={CFG_COLOR,"MESSAGEWIN_STATUS_BGCOLOR",0,0};
__root const char MESSAGEWIN_STATUS_BGCOLOR_c[4]={0x9B,0xFF,0xB4,0x64};

__root const CFG_HDR cfgcolor24={CFG_COLOR,"MESSAGEWIN_CHAT_FONT",0,0};
__root const char MESSAGEWIN_CHAT_FONT_c[4]={0x00,0x00,0x00,0x64};

__root const CFG_HDR cfgcolor25={CFG_COLOR,"Online",0,0};
__root const char OnlineColor_c[4]={0x00,0x00,0x7F,0x64};

__root const CFG_HDR cfgcolor26={CFG_COLOR,"Chat",0,0};
__root const char ChatColor_c[4]={0x00,0xFF,0x00,0x64};

__root const CFG_HDR cfgcolor27={CFG_COLOR,"Away",0,0};
__root const char AwayColor_c[4]={0x00,0x00,0xFF,0x64};

__root const CFG_HDR cfgcolor28={CFG_COLOR,"XA",0,0};
__root const char XAColor_c[4]={0x00,0x7F,0x00,0x64};

__root const CFG_HDR cfgcolor29={CFG_COLOR,"DND",0,0};
__root const char DNDColor_c[4]={0xFF,0x00,0x00,0x64};

__root const CFG_HDR cfgcolor30={CFG_COLOR,"Invisible",0,0};
__root const char InvisibleColor_c[4]={0x7F,0x7F,0x7F,0x64};

__root const CFG_HDR cfgcolor31={CFG_COLOR,"Offline",0,0};
__root const char OfflineColor_c[4]={0xAA,0xAA,0xAA,0x64};

__root const CFG_HDR cfgcolor32={CFG_COLOR,"Error",0,0};
__root const char ErrorColor_c[4]={0x7F,0x7F,0x7F,0x64};

__root const CFG_HDR cfgcolor33={CFG_COLOR,"Subscribe",0,0};
__root const char SubscribeColor_c[4]={0xAA,0xAA,0xAA,0x64};

__root const CFG_HDR cfgcolor34={CFG_COLOR,"Subscribed",0,0};
__root const char SubscribedColor_c[4]={0xAA,0xAA,0xAA,0x64};

__root const CFG_HDR cfgcolor35={CFG_COLOR,"Unsubscribe",0,0};
__root const char UnsubscribeColor_c[4]={0xAA,0xAA,0xAA,0x64};

__root const CFG_HDR cfgcolor36={CFG_COLOR,"Unsubscribed",0,0};
__root const char UnsubscribedColor_c[4]={0xAA,0xAA,0xAA,0x64};

// EOL, EOF

__CFG_END(1)
