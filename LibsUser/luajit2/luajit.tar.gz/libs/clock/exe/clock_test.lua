

local clock = require('clock')




print('Second: '..clock.time().sec)
print('Minute: '..clock.time().min)
print('Hour: '..clock.time().hour)
