

#ifndef __LUALIB_H__
#define __LUALIB_H__



#define LUA_SYSNAME "sys"
int luaopen_sys (lua_State *L);



#endif
