
#ifndef __STD_INIT_H__
#define __STD_INIT_H__


void std_init(const char *script);



#endif
