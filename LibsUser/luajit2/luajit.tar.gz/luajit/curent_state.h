
#ifndef __CURENT_LUA_STATE_H__
#define __CURENT_LUA_STATE_H__

#include <lua.h>

extern lua_State *curent_lstate;


#endif
